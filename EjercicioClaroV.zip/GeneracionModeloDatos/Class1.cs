﻿using System;

namespace GeneracionModeloDatos
{
    public class Class1
    {
    }
}
