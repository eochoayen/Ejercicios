--verificando sqlite

select * from Listas where ListaId in ('46180748', '46700892', '46700837');


select * from DetalleLista;